DELETE FROM scholarapp_followers;
DELETE FROM scholarapp_profile WHERE user_id=23;
DELETE FROM scholarapp_customuser WHERE ID=23;
-- DELETE FROM online_users_onlineuseractivity WHERE user_id=9;
-- DELETE FROM scholarapp_event_authors WHERE event_id=87; 
-- DELETE FROM scholarapp_event WHERE ID=87;
-- DELETE FROM scholarapp_message;
-- DELETE FROM scholarapp_conversation_users WHERE ID IN (43,44);
-- DELETE FROM scholarapp_conversation WHERE ID=32;
-- DELETE FROM scholarapp_message WHERE parent_conversation_id=31