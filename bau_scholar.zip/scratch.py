import os

from scholarapp.utils.common import filter_above_year

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "myproject.settings")
from django.conf import settings
import django

django.setup()


print(filter_above_year(2020))
