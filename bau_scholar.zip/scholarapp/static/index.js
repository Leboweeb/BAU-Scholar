function participateInEvent(event) {
  let currentTarget = event.currentTarget;
  let event_id = currentTarget.parentElement.dataset.eventId;
  let has_participated_svg = new DOMParser().parseFromString(
    `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-check" viewBox="0 0 16 16">
  <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7m1.679-4.493-1.335 2.226a.75.75 0 0 1-1.174.144l-.774-.773a.5.5 0 0 1 .708-.708l.547.548 1.17-1.951a.5.5 0 1 1 .858.514M11 5a3 3 0 1 1-6 0 3 3 0 0 1 6 0M8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4"/>
  <path d="M8.256 14a4.5 4.5 0 0 1-.229-1.004H3c.001-.246.154-.986.832-1.664C4.484 10.68 5.711 10 8 10q.39 0 .74.025c.226-.341.496-.65.804-.918Q8.844 9.002 8 9c-5 0-6 3-6 4s1 1 1 1z"/>
</svg>
        `,
    "text/html"
  ).body.firstElementChild;

  let hasnt_participated_svg = new DOMParser().parseFromString(
    `
                    <svg xmlns="http://www.w3.org/2000/svg"
                         width="16"
                         height="16"
                         fill="currentColor"
                         class="bi bi-person-add"
                         viewBox="0 0 16 16">
                        <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7m.5-5v1h1a.5.5 0 0 1 0 1h-1v1a.5.5 0 0 1-1 0v-1h-1a.5.5 0 0 1 0-1h1v-1a.5.5 0 0 1 1 0m-2-6a3 3 0 1 1-6 0 3 3 0 0 1 6 0M8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4" />
                        <path d="M8.256 14a4.5 4.5 0 0 1-.229-1.004H3c.001-.246.154-.986.832-1.664C4.484 10.68 5.711 10 8 10q.39 0 .74.025c.226-.341.496-.65.804-.918Q8.844 9.002 8 9c-5 0-6 3-6 4s1 1 1 1z" />
                    </svg>
        `,
    "text/html"
  ).body.firstElementChild;

  let has_participated =
    currentTarget.children[0].classList[1] === "bi-person-check";

  let element_to_swap = has_participated
    ? hasnt_participated_svg
    : has_participated_svg;
  fetch("/participate_in_event", {
    method: "post",
    headers: {
      "X-CSRFToken": `${csrf_token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      event_id: event_id,
      has_participated: has_participated,
    }),
  }).then((response) => {
    currentTarget.children[0].replaceWith(element_to_swap);
  });
}

let toggleCustomTab = (event) => {
  let currentTarget = event.currentTarget;
  let tabs = document.querySelectorAll(".custom-tab");
  let searchOptions = "People,Research,Events,Tags"
    .split(",")
    .map((val) => val.toLowerCase());
  let index;
  if (currentTarget.tagName === "BUTTON") {
    index = indexFromSelector(".custom-tab", currentTarget);
  } else {
    index = searchOptions.indexOf(currentTarget.value);
    if (index === -1) {
      tabs.forEach((elem) => elem.classList.remove("custom-tab-active"));
    }
  }
  let searchDropDown = document.querySelector("#search_in");
  tabs[index].classList.add("custom-tab-active");
  exceptIndex(tabs, index).forEach((elem) =>
    elem.classList.remove("custom-tab-active")
  );
  searchDropDown.value = searchOptions[index];
};

function getSearchParams() {
  // the search dropdown will always mirror the selected tab, no need to check tabs as well.
  let searchDropDown = document.querySelector("#search_in").value;
  return searchDropDown;
}

function paramChangedEvent() {
  htmx.trigger('input[name="event_search"]', "paramsChanged");
}
